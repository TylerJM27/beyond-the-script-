import works1 from "../assets/images/works1.jpg";
import works2 from "../assets/images/actress-profile.jpg";
import works3 from "../assets/images/works3.jpg";

export const WORKS = [
    {
        id: 0,
        altText: "Slide 1",
        image: works1,
    },
    {
        id: 1,
        altText: "Slide 2",
        image: works2,
    },
    {
        id: 2,
        altText: "Slide 3",
        image: works3,
    },
];
