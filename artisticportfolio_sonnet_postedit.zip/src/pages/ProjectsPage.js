import Header from "../components/Header";
import CarouselOfImages from "../components/CarouselOfImages";

const ProjectsPage = () => {
    return (
        <div className="bg-[#eae7dc] h-screen overflow-hidden flex flex-col">
            <div className="w-full">
                <Header />
            </div>

            {/* Carousel container with responsive height */}
            <div className="flex-grow flex items-center justify-center">
                {/* Pass showProjectDetails prop to enable project overlays */}
                <div className="w-full h-full md:h-auto md:max-h-[80vh]">
                    <CarouselOfImages showProjectDetails={true} />
                </div>
            </div>
        </div>
    );
};

export default ProjectsPage;
