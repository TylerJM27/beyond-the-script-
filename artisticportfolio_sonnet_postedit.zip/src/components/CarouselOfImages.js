import { useState } from "react";
import {
    Carousel,
    CarouselItem,
    CarouselControl,
    CarouselIndicators,
} from "reactstrap";
import { WORKS } from "../app/shared/WORKS";

const CarouselOfImages = ({ showProjectDetails = false }) => {
    const [activeIndex, setActiveIndex] = useState(0);
    const [animating, setAnimating] = useState(false);

    // These functions are correct, the issue might be with the Reactstrap component
    // Let's ensure we're properly binding them to the controls
    const nextSlide = () => {
        if (animating) return;
        const nextIndex =
            activeIndex === WORKS.length - 1 ? 0 : activeIndex + 1;
        setActiveIndex(nextIndex);
    };

    const prevSlide = () => {
        if (animating) return;
        const prevIndex =
            activeIndex === 0 ? WORKS.length - 1 : activeIndex - 1;
        setActiveIndex(prevIndex);
    };

    const goToIndex = (newIndex) => {
        if (animating) return;
        setActiveIndex(newIndex);
    };

    // Added project details overlay for ProjectsPage
    const slides = WORKS.map((work) => {
        return (
            <CarouselItem
                onExiting={() => setAnimating(true)}
                onExited={() => setAnimating(false)}
                key={work.image}
                slide
            >
                <div className="relative w-full h-full">
                    <img
                        src={work.image}
                        alt={work.altText}
                        className="w-full h-full object-contain"
                    />

                    {/* Project details overlay - only shown when showProjectDetails is true */}
                    {showProjectDetails && (
                        <>
                            {/* Project title in top left */}
                            <div className="absolute top-4 left-4 bg-black bg-opacity-50 text-white p-2 rounded">
                                {work.altText || "Project Title"}
                            </div>

                            {/* Project link in bottom right */}
                            {work.projectUrl && (
                                <a
                                    href={work.projectUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="absolute bottom-4 right-4 bg-black bg-opacity-50 text-white p-2 rounded hover:bg-opacity-70 transition-all"
                                >
                                    View Project
                                </a>
                            )}
                        </>
                    )}
                </div>
            </CarouselItem>
        );
    });

    return (
        <div className="px-4 py-4 md:px-8 md:py-6 shadow-md rounded-lg">
            <Carousel
                className="w-full h-full"
                activeIndex={activeIndex}
                next={nextSlide}
                previous={prevSlide}
                pause="hover"
                enableTouch
                dark
            >
                <CarouselIndicators
                    items={WORKS}
                    activeIndex={activeIndex}
                    onClickHandler={goToIndex}
                />
                {slides}
                <CarouselControl
                    direction="prev"
                    directionText="Previous"
                    onClickHandler={prevSlide}
                />
                <CarouselControl
                    direction="next"
                    directionText="Next"
                    onClickHandler={nextSlide}
                />
            </Carousel>
        </div>
    );
};

export default CarouselOfImages;
